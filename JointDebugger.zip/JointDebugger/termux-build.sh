#!/data/data/com.termux/files/usr/bin/bash
# =============================================================================
# Joint Position Debugger - Termux Build & Install Script
# Chạy lệnh:  bash termux-build.sh
# =============================================================================
set -e

# Dừng nếu lỗi, in ra từng bước đang làm
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

say() { echo -e "${GREEN}==>${NC} $1"; }
warn() { echo -e "${YELLOW}!!  ${NC} $1"; }
die() { echo -e "${RED}xx  ${NC} $1"; exit 1; }

# ---------------------------------------------------------------------------
# BƯỚC 1: Cập nhật Termux + cài package cơ bản
# ---------------------------------------------------------------------------
say "Bước 1/7: Cập nhật Termux và cài packages cơ bản"
pkg update -y
pkg upgrade -y
pkg install -y git wget curl unzip clang make openssl-tool proot nano

# ---------------------------------------------------------------------------
# BƯỚC 2: Cài .NET 8 SDK
# ---------------------------------------------------------------------------
say "Bước 2/7: Cài .NET 8 SDK (khoảng 1-2 phút)"
if ! command -v dotnet &> /dev/null; then
    # Cách 1: thử cài qua package manager của Termux (nhanh nhất)
    if pkg install -y dotnet-host-8.0 2>/dev/null; then
        if ! command -v dotnet &> /dev/null; then
            pkg install -y dotnet-host-9.0 2>/dev/null || true
        fi
    fi
fi

# Cách 2: cài SDK qua script của Microsoft
if ! command -v dotnet &> /dev/null || ! dotnet --list-sdks 2>/dev/null | grep -q "8\."; then
    say "  Cài .NET SDK qua script chính thức..."
    cd ~
    curl -L -s -o dotnet-install.sh https://dot.net/v1/dotnet-install.sh
    chmod +x dotnet-install.sh
    ./dotnet-install.sh --channel 8.0 --install-dir $PREFIX/share/dotnet
    rm dotnet-install.sh
    export DOTNET_ROOT=$PREFIX/share/dotnet
    export PATH=$PREFIX/share/dotnet:$PATH
fi

export DOTNET_ROOT=$PREFIX/share/dotnet
export PATH=$PREFIX/share/dotnet:$PATH

# Lưu vào bashrc để lần sau mở Termux không phải set lại
grep -q "DOTNET_ROOT" ~/.bashrc || cat >> ~/.bashrc <<'EOF'

# .NET 8 SDK
export DOTNET_ROOT=$PREFIX/share/dotnet
export PATH=$PREFIX/share/dotnet:$PATH
EOF

if ! command -v dotnet &> /dev/null; then
    die "Không cài được .NET SDK. Kiểm tra mạng rồi thử lại."
fi

# Có thể chỉ có host mà chưa có SDK — check
if ! dotnet --list-sdks 2>/dev/null | grep -q "8\."; then
    say "  Có dotnet host nhưng chưa có SDK, tải SDK..."
    cd ~
    [ -f dotnet-install.sh ] || curl -L -s -o dotnet-install.sh https://dot.net/v1/dotnet-install.sh
    chmod +x dotnet-install.sh
    ./dotnet-install.sh --channel 8.0 --install-dir $PREFIX/share/dotnet
    rm dotnet-install.sh
fi

dotnet --version || die "Không cài được .NET SDK"
say "  .NET $(dotnet --version) OK"

# ---------------------------------------------------------------------------
# BƯỚC 3: Cài Android SDK Command-line Tools
# ---------------------------------------------------------------------------
say "Bước 3/7: Cài Android SDK (khoảng 3-5 phút tùy mạng)"
ANDROID_HOME=$PREFIX/lib/android-sdk
export ANDROID_HOME

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    mkdir -p $ANDROID_HOME/cmdline-tools
    cd $ANDROID_HOME/cmdline-tools
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q commandlinetools-linux-11076708_latest.zip
    mv cmdline-tools latest
    rm commandlinetools-linux-11076708_latest.zip
    cd ~
fi

export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH

# Lưu vào bashrc
grep -q "ANDROID_HOME" ~/.bashrc || cat >> ~/.bashrc <<'EOF'

# Android SDK
export ANDROID_HOME=$PREFIX/lib/android-sdk
export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH
EOF

# ---------------------------------------------------------------------------
# BƯỚC 4: Đồng ý licenses + cài platforms + build-tools
# ---------------------------------------------------------------------------
say "Bước 4/7: Đồng ý licenses và cài Android platform 34"
yes | sdkmanager --licenses > /dev/null 2>&1 || warn "Cần đồng ý licenses thủ công, đang tiếp tục..."
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
say "  Android SDK OK"

# ---------------------------------------------------------------------------
# BƯỚC 5: Copy project vào thư mục làm việc
# ---------------------------------------------------------------------------
say "Bước 5/7: Chuẩn bị project source code"
cd ~

# Nếu project chưa có ở ~/JointDebugger, hỏi người dùng
if [ ! -d ~/JointDebugger/JointDebugger.csproj ]; then
    warn "Không tìm thấy ~/JointDebugger/"
    echo ""
    echo "Bạn có 2 cách copy project vào:"
    echo ""
    echo "CÁCH 1: Copy thủ công bằng file manager"
    echo "  - Mở file manager trên Android"
    echo "  - Copy thư mục JointDebugger/ vào /data/data/com.termux/files/home/"
    echo "  - Quay lại đây, bấm Enter"
    echo ""
    echo "CÁCH 2: Dùng git (nếu project ở GitHub)"
    echo "  Ví dụ: git clone https://github.com/yourname/JointDebugger.git"
    echo ""
    read -p "Bấm Enter khi đã copy xong (hoặc Ctrl+C để hủy)..."

    if [ ! -d ~/JointDebugger/JointDebugger.csproj ]; then
        die "Vẫn không thấy ~/JointDebugger/JointDebugger.csproj. Hãy copy project vào trước."
    fi
fi

cd ~/JointDebugger
say "  Project tại $(pwd)"

# ---------------------------------------------------------------------------
# BƯỚC 6: Build app
# ---------------------------------------------------------------------------
say "Bước 6/7: Build project (lần đầu khoảng 5-10 phút, restore NuGet packages)"
dotnet restore
dotnet build -c Release

APK_PATH="bin/Release/net8.0-android/com.jointdebugger.app-Signed.apk"
if [ ! -f "$APK_PATH" ]; then
    die "Build xong nhưng không thấy APK ở $APK_PATH"
fi
say "  Build OK → $APK_PATH"

# ---------------------------------------------------------------------------
# BƯỚC 7: Cài lên điện thoại
# ---------------------------------------------------------------------------
say "Bước 7/7: Cài APK lên điện thoại"

# Thử adb trước
if adb devices 2>/dev/null | grep -q "device$"; then
    say "  Tìm thấy thiết bị qua adb, đang cài..."
    adb install -r "$APK_PATH"
else
    # Không có adb - copy APK ra Downloads để cài thủ công
    warn "  Không thấy thiết bị adb, copy APK ra ~/storage/downloads/"
    cp "$APK_PATH" ~/storage/downloads/JointDebugger.apk
    echo ""
    echo "  APK đã được copy đến: /storage/emulated/0/Download/JointDebugger.apk"
    echo "  Mở File Manager trên Android → Download → tap 'JointDebugger.apk' để cài"
    echo ""
fi

say "============================================="
say "XONG RỒI! 🎉"
say "============================================="
echo ""
echo "Tiếp theo:"
echo "  1. Mở app 'Joint Position Debugger' từ launcher"
echo "  2. App sẽ tự mở Settings, cấp quyền 'Display over other apps'"
echo "  3. Quay lại app, overlay sẽ tự chạy"
echo ""
echo "Để build lại sau khi sửa code:"
echo "  cd ~/JointDebugger && dotnet build -c Release && adb install -r bin/Release/net8.0-android/com.jointdebugger.app-Signed.apk"
echo ""
